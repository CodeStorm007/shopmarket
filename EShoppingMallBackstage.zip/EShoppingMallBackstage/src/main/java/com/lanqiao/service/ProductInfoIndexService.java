package com.lanqiao.service;

import java.util.List;

import com.lanqiao.entity.ProductInfo;

public interface ProductInfoIndexService {
	    // 添加商品索引
		public int addProduct(ProductInfo p) throws Exception;

		// 删除商品索引
		public int deleteProduct(Integer productId) throws Exception;

		// 更新商品索引
		public int updateProduct(ProductInfo p) throws Exception;
		
		//根据关键字获得商品索引
		public List<ProductInfo> queryAllProduct(String key) throws Exception;
}
