package com.lanqiao.service.impl;

import java.util.ArrayList;
import java.util.List;

import org.apache.lucene.analysis.Analyzer;
import org.apache.lucene.document.Document;
import org.apache.lucene.index.DirectoryReader;
import org.apache.lucene.index.IndexReader;
import org.apache.lucene.index.IndexWriter;
import org.apache.lucene.index.IndexWriterConfig;
import org.apache.lucene.index.Term;
import org.apache.lucene.queryparser.classic.MultiFieldQueryParser;
import org.apache.lucene.queryparser.classic.QueryParser;
import org.apache.lucene.search.IndexSearcher;
import org.apache.lucene.search.Query;
import org.apache.lucene.search.ScoreDoc;
import org.apache.lucene.search.TopDocs;
import org.springframework.stereotype.Service;
import org.wltea.analyzer.lucene.IKAnalyzer;

import com.lanqiao.entity.ProductInfo;
import com.lanqiao.service.ProductInfoIndexService;
import com.lanqiao.utils.LuceneUtil;

@Service
public class ProductInfoIndexServiceImpl implements ProductInfoIndexService {

	public int addProduct(ProductInfo p) throws Exception {
		Document doc = LuceneUtil.objectToDocument(p);

		// 创建分词器，标准分词器
		Analyzer analyzer = new IKAnalyzer();

		// 创建IndexWriter
		IndexWriterConfig cfg = new IndexWriterConfig(analyzer);

		IndexWriter writer = new IndexWriter(LuceneUtil.getDirectory(), cfg);

		writer.addDocument(doc);

		// 关闭writer
		writer.close();

		return 0;
	}

	@Override
	public int deleteProduct(Integer productId) throws Exception {
		// 创建IndexWriter
		IndexWriterConfig cfg = new IndexWriterConfig(LuceneUtil.getAnalyzer());

		IndexWriter writer = new IndexWriter(LuceneUtil.getDirectory(), cfg);

		writer.deleteDocuments(new Term("productId", String.valueOf(productId)));

		// 关闭writer
		writer.close();

		return 0;
	}

	@Override
	public int updateProduct(ProductInfo p) throws Exception {
		deleteProduct(p.getProductId());

		addProduct(p);

		return 0;
	}

	@Override
	public List<ProductInfo> queryAllProduct(String key) throws Exception {
		List<ProductInfo> list = new ArrayList<ProductInfo>();
		// 创建索引的读取器
		IndexReader indexReader = DirectoryReader.open(LuceneUtil.getDirectory());

		// 创建一个索引的查找器，来检索索引库
		IndexSearcher indexSearcher = new IndexSearcher(indexReader);

		// 创建需要用于查询的字段数组
		String[] fields = { "productName", "productDescription", "productPicture", "productPrice", "productStock",
				"categoryId", "categoryParentId" };
		// 创建查询用的类
		QueryParser queryParser = new MultiFieldQueryParser(fields, new IKAnalyzer());
		// 查询符合关键字的数据
		Query query = queryParser.parse(key);

		TopDocs topDocs = indexSearcher.search(query, 100);

		// 打印查询到的记录数
		System.out.println("总记录数:" + topDocs.totalHits);

		// 得到得分文档数组
		ScoreDoc scoreDocs[] = topDocs.scoreDocs;

		// 遍历数组，返回一个击中
		for (ScoreDoc scoreDoc : scoreDocs) {

			int docID = scoreDoc.doc;

			// 取得对应的文档对象
			Document document = indexSearcher.doc(docID);

			ProductInfo p = LuceneUtil.documentToObject(document);
			list.add(p);
		}

		return list;
	}

}
