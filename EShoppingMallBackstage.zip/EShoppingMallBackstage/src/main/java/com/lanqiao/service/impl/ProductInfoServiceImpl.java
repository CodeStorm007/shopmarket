package com.lanqiao.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.lanqiao.dao.CategoryDao;
import com.lanqiao.dao.ProductInfoDao;
import com.lanqiao.entity.ProductInfo;
import com.lanqiao.service.ProductInfoService;

@Service
public class ProductInfoServiceImpl implements ProductInfoService {

	@Autowired
	private ProductInfoDao pd;
	@Autowired
	private CategoryDao cd;

	public List<ProductInfo> queryAllProduct() {

		return pd.queryAllProduct();
	}

	public ProductInfo queryProductById(int product_id) throws Exception {

		return pd.queryProductById(product_id);
	}

	public List<ProductInfo> queryProductByType(int category_id) throws Exception {

		return pd.queryProductByType(category_id);
	}

	public List<ProductInfo> queryProductByParentType(int category_parent_id) throws Exception {

		return pd.queryProductByParentType(category_parent_id);
	}

	// 返回0代表添加失败
	public int addProduct(ProductInfo p) throws Exception {
		List li = cd.queryAllId();
		if (!li.contains(p.getCategoryId())) {
			return 0;
		}
		li = cd.queryAllParentId();
		if (!li.contains(p.getCategoryParentId())) {
			return 0;
		}
		return pd.addProduct(p);
	}

	// 返回0代表删除失败
	public int deleteProduct(Integer productId) throws Exception {

		return pd.deleteProduct(productId);
	}

	// 返回0代表更新失败
	public int updateProduct(ProductInfo p) throws Exception {
		List li = cd.queryAllId();
		if (!li.contains(p.getCategoryId())) {
			return 0;
		}
		li = cd.queryAllParentId();
		if (!li.contains(p.getCategoryParentId())) {
			return 0;
		}
		return pd.updateProduct(p);
	}

	@Override
	public List queryAllCategoryId() throws Exception {
		return pd.queryAllCategoryId();
	}

	public int queryProductStock(Integer product_id) throws Exception {
		return pd.queryProductStock(product_id);
	}

	public int reduceProductStock(Integer product_id, Integer order_quantity) throws Exception {
		return pd.reduceProductStock(product_id, order_quantity);
	}

	public int addProductStock(Integer product_id, Integer order_quantity) throws Exception {
		return pd.addProductStock(product_id, order_quantity);
	}

	@Override
	public double queryPriceByProductId(int productId) throws Exception {
		return pd.queryPriceByProductId(productId);
	}

}
