package com.lanqiao.service;

import java.util.List;

import org.apache.ibatis.annotations.Param;

import com.github.pagehelper.PageInfo;
import com.lanqiao.entity.ShoppingCart;
import com.lanqiao.vo.ShoppingProductVO;

public interface ShoppingCartService {
	// 查询购物车表
	List<ShoppingCart> getAll();

	// 根据用户查询用户商品信息、数量、单价、商品名字
	List<ShoppingProductVO> getByUserId(int userId);

	// 商品加入购物车
	int insertCart(ShoppingCart shopcaCart);

	// 根据用户id更新数据库中商品的数量
	int update(int orderQuantity, int productId, int userId);

	/**
	 * 
	 * @param userid
	 * @param productId
	 * @return 根据用户编号和商品编号删除商品
	 */
	int delete(@Param("userId") int userId, @Param("productId") int productId);

	/**
	 * 
	 * @param pageno
	 * @param pagesize
	 * @return
	 */
	PageInfo<ShoppingCart> getpage(int pageno, int pagesize);

}
