package com.lanqiao.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import com.lanqiao.dao.ShoppingCartDao;
import com.lanqiao.entity.ShoppingCart;
import com.lanqiao.service.ShoppingCartService;
import com.lanqiao.vo.ShoppingProductVO;

@Service
public class ShoppingCartServiceImpl implements ShoppingCartService {
	@Autowired
	private ShoppingCartDao dao;

	public List<ShoppingCart> getAll() {
		// TODO Auto-generated method stub
		return dao.getAll();
	}

	@Override
	public List<ShoppingProductVO> getByUserId(int userId) {
		// TODO Auto-generated method stub
		return dao.getByUserId(userId);
	}

	@Override
	public int insertCart(ShoppingCart shopcaCart) {
		// TODO Auto-generated method stub
		return dao.insertCart(shopcaCart);
	}

	@Override
	public int update(int orderQuantity, int productId, int userId) {
		// TODO Auto-generated method stub
		return dao.update(orderQuantity, productId, userId);
	}

	@Override
	public int delete(int userId, int productId) {
		// TODO Auto-generated method stub
		return dao.delete(userId, productId);
	}

	@Override
	public PageInfo<ShoppingCart> getpage(int pageno, int pagesize) {
		PageHelper.startPage(pageno, pagesize);

		List<ShoppingCart> list = dao.getAll();
		// 页码数量每页显示【可以不写，默认为8个】
		PageInfo<ShoppingCart> pageInfo = new PageInfo<>(list, 4);
		return pageInfo;
	}

}
