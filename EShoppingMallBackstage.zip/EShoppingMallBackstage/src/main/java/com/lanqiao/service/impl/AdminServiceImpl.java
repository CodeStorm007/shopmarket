package com.lanqiao.service.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.lanqiao.dao.AdminDao;
import com.lanqiao.entity.Admin;
import com.lanqiao.service.AdminService;

@Service
public class AdminServiceImpl implements AdminService {

	@Autowired
	private AdminDao ad;

	@Override
	public Admin queryAdminById(int adminId) throws Exception {
		// TODO Auto-generated method stub
		return ad.queryAdminById(adminId);
	}

	@Override
	public int updateAdmin(Admin a) throws Exception {
		// TODO Auto-generated method stub
		return ad.updateAdmin(a);
	}

	@Override
	public int deleteAdmin(int adminId) throws Exception {
		// TODO Auto-generated method stub
		return ad.deleteAdmin(adminId);
	}

	@Override
	public Admin query(String adminName, String adminPassword) throws Exception {
		// TODO Auto-generated method stub
		return ad.query(adminName, adminPassword);
	}

	@Override
	public Admin queryAdminByName(String adminName) throws Exception {
		// TODO Auto-generated method stub
		return ad.queryAdminByName(adminName);
	}

	@Override
	public Admin queryAdminByMobile(String adminMobile) throws Exception {
		// TODO Auto-generated method stub
		return ad.queryAdminByMobile(adminMobile);
	}

	@Override
	public int addAdmin(Admin a) throws Exception {
		// TODO Auto-generated method stub
		return ad.addAdmin(a);
	}

	@Override
	public Admin queryAdminByPassword(String adminPassword) throws Exception {
		// TODO Auto-generated method stub
		return null;
	}

}
