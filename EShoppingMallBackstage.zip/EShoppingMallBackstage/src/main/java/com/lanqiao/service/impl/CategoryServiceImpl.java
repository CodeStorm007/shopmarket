package com.lanqiao.service.impl;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.lanqiao.dao.CategoryDao;
import com.lanqiao.dao.ProductInfoDao;
import com.lanqiao.entity.Category;
import com.lanqiao.service.CategoryService;
import com.lanqiao.vo.MenuTree;

@Service
public class CategoryServiceImpl implements CategoryService {

	@Autowired
	private CategoryDao cd;
	@Autowired
	private ProductInfoDao pd;

	public List<Category> queryAllCategory() throws Exception {

		return cd.queryAllCategory();
	}

	public List<Category> queryCategoryById(int categoryId) throws Exception {

		return cd.queryCategoryById(categoryId);
	}

	public List<Category> queryCategoryByParentId(int categoryParentId) throws Exception {

		return cd.queryCategoryByParentId(categoryParentId);
	}

	// 返回0代表添加失败
	public int addCategory(Category c) throws Exception {
		// 不可添加已有的商品类别
		List<Category> li = cd.queryAllCategory();
		for (Category cg : li) {
			if (cg.getCategoryName().equals(c.getCategoryName())) {
				return 0;
			}
		}
		// 添加的二级分类必须是一级分类中已有的,除非二级分类为0
		if (c.getCategoryParentId() != 0) {
			List l = cd.queryAllId();
			System.out.println(l);
			boolean b = l.contains(c.getCategoryParentId());
			System.out.println(b);
			if (!l.contains(c.getCategoryParentId())) {
				return 0;
			}
			return cd.addCategory(c);
		}
		return cd.addCategory(c);
	}

	// 返回0代表删除失败，只能删除商品表中未用到的分类
	public int deleteCategory(Integer categoryId) throws Exception {
		List li = pd.queryAllCategoryId();
		if (li.contains(categoryId)) {
			return 0;
		}
		return cd.deleteCategory(categoryId);
	}

	// 返回0代表修改失败
	public int updateCategory(Category c) throws Exception {
		// 不可修改成已有的商品类别
		List<Category> li = cd.queryAllCategory();
		for (Category cg : li) {
			if (cg.getCategoryName().equals(c.getCategoryName())) {
				return 0;
			}
		}
		// 修改的二级分类必须是一级分类中已有的,除非二级分类为0
		if (c.getCategoryParentId() != 0) {
			List l = cd.queryAllId();
			if (!l.contains(c.getCategoryParentId())) {
				return 0;
			}
		}
		return cd.updateCategory(c);
	}

	public List queryAllId() throws Exception {
		return cd.queryAllId();
	}

	public List queryAllParentId() throws Exception {
		return cd.queryAllParentId();
	}

	public List<MenuTree> getMenuTree() throws Exception {
		List<MenuTree> tree = new ArrayList<MenuTree>();
		List<Category> lm = cd.queryAllCategory();

		for (int i = 0; i < lm.size(); i++) {
			Category m = lm.get(i);
			// 如果是一级菜单
			if (m.getCategoryParentId() == 1) {
				MenuTree mt = new MenuTree();
				mt.setCid(m.getCategoryId());
				mt.setLabel(m.getCategoryName());
				// 这个一级菜单的children
				List<MenuTree> subtree = new ArrayList<MenuTree>();
				// 重新遍历所有菜单，然后找出这个一级菜单的children
				for (int j = 0; j < lm.size(); j++) {
					if (lm.get(j).getCategoryParentId() == m.getCategoryId()) {
						// 二级菜单
						MenuTree mt2 = new MenuTree();
						mt2.setCid(lm.get(j).getCategoryId());
						mt2.setLabel(lm.get(j).getCategoryName());
						subtree.add(mt2);
					}
				}
				mt.setChildren(subtree);

				tree.add(mt);

			}
		}

		return tree;
	}

}
