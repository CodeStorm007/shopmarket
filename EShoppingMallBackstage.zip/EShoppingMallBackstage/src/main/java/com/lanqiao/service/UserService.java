package com.lanqiao.service;

import com.lanqiao.entity.User;

public interface UserService {

	User findByUsername(String userName);

	public User login(String userName, String passWord);

	public int register(User user);

	// 获取用户id跟昵称
	public User GainNameId(String userName);

	public User userNameTest(String userName);

	public User userMobileTest(String userMoblie);

	public User userEmailTest(String userEmail);

	public User userNickNameTest(String userNickName);

}
