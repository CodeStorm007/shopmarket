package com.lanqiao.service;

import com.lanqiao.entity.Admin;

public interface AdminService {

	// 根据所有管理元员id查询
	public Admin queryAdminById(int adminId) throws Exception;

	// 根据管理员姓名查询
	public Admin queryAdminByName(String adminName) throws Exception;

	// 根据电话号码查询管理员
	public Admin queryAdminByMobile(String adminMobile) throws Exception;

	// 根据密码查询
	public Admin queryAdminByPassword(String adminPassword) throws Exception;

	// 查用户名密码
	public Admin query(String adminName, String adminPassword) throws Exception;

	// 更新管理员
	public int updateAdmin(Admin a) throws Exception;

	// 增加管理员
	public int addAdmin(Admin a) throws Exception;

	// 删除管理员
	public int deleteAdmin(int adminId) throws Exception;

}
