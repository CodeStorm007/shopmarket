package com.lanqiao.service;

import java.util.List;

import com.lanqiao.entity.Category;
import com.lanqiao.vo.MenuTree;

public interface CategoryService {
	public List<MenuTree> getMenuTree() throws Exception;

	// 查询所有分类
	public List<Category> queryAllCategory() throws Exception;

	// 根据所属分类ID查询分类
	public List<Category> queryCategoryById(int categoryId) throws Exception;

	// 根据所属二级分类ID查询分类
	public List<Category> queryCategoryByParentId(int categoryParentId) throws Exception;

	// 添加分类
	public int addCategory(Category c) throws Exception;

	// 删除分类
	public int deleteCategory(Integer categoryId) throws Exception;

	// 更新分类
	public int updateCategory(Category c) throws Exception;

	// 查询所有一级分类ID
	public List queryAllId() throws Exception;

	// 查询所有二级分类ID
	public List queryAllParentId() throws Exception;
}
