package com.lanqiao.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.lanqiao.dao.CommentDao;
import com.lanqiao.entity.Comment;
import com.lanqiao.service.CommentService;
import com.lanqiao.vo.CommentVoProduct;

@Service
public class CommentServiceImpl implements CommentService {
	@Autowired
	private CommentDao dao;

	@Override
	public List<CommentVoProduct> showAllCommentByProId(int productId) {
		// TODO Auto-generated method stub
		return dao.showAllCommentByProId(productId);
	}

	@Override
	public int addComment(Comment o) throws Exception {
		return dao.addComment(o);
	}

}
