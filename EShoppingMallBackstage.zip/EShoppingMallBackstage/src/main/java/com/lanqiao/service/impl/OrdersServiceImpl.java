package com.lanqiao.service.impl;

import java.sql.SQLException;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.lanqiao.dao.OrdersDao;
import com.lanqiao.entity.Orders;
import com.lanqiao.service.OrdersService;
import com.lanqiao.vo.OrderVoAdmin;
import com.lanqiao.vo.OrderVoUser;

@Service
public class OrdersServiceImpl implements OrdersService {

	@Autowired
	private OrdersDao od;

	public List<OrderVoAdmin> queryAllOrders() throws Exception {
		return od.queryAllOrders();
	}

	public OrderVoAdmin queryOrdersById(int order_id) throws Exception {
		return od.queryOrdersById(order_id);
	}

	public List<OrderVoUser> queryOrdersByUserId(int user_id) throws Exception {
		return od.queryOrdersByUserId(user_id);
	}

	public int addOrders(Orders o) throws Exception {
		return od.addOrders(o);
	}

	public int deleteOrders(int user_id, int order_id) throws Exception {
		return od.deleteOrders(user_id, order_id);
	}

	public int updateOrders(int order_status, int order_id) throws Exception {
		return od.updateOrders(order_status, order_id);
	}

	@Override
	public List<OrderVoUser> queryProductMsgByPD(String productDescription) throws SQLException {
		return od.queryProductMsgByPD(productDescription);
	}

}
