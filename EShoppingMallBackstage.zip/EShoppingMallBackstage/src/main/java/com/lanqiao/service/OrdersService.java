package com.lanqiao.service;

import java.sql.SQLException;
import java.util.List;

import org.apache.ibatis.annotations.Param;

import com.lanqiao.entity.Orders;
import com.lanqiao.vo.OrderVoAdmin;
import com.lanqiao.vo.OrderVoUser;

public interface OrdersService {

	// 查询所有订单-管理员
	public List<OrderVoAdmin> queryAllOrders() throws Exception;

	// 根据订单编号查询订单-管理员
	public OrderVoAdmin queryOrdersById(int order_id) throws Exception;

	// 根据用户编号查询订单-用户
	public List<OrderVoUser> queryOrdersByUserId(int user_id) throws Exception;

	// 添加订单-用户
	public int addOrders(Orders o) throws Exception;

	// 删除订单-用户取消
	public int deleteOrders(int user_id, int order_id) throws Exception;

	// 更新订单-管理员
	public int updateOrders(@Param("order_status") int order_status, @Param("order_id") int order_id) throws Exception;

	// 根据商品描述关键字模糊查询订单
	public List<OrderVoUser> queryProductMsgByPD(@Param("productDescription") String productDescription)
			throws SQLException;
}
