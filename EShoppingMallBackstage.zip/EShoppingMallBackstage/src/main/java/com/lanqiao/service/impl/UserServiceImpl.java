package com.lanqiao.service.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.lanqiao.entity.User;
import com.lanqiao.service.UserService;

@Service
public class UserServiceImpl implements UserService {
	@Autowired
	private com.lanqiao.dao.UserDao UserDao;

	@Override
	public User login(String userName, String passWord) {
		// TODO Auto-generated method stub
		return UserDao.login(userName, passWord);
	}

	@Override
	public User findByUsername(String userName) {
		// TODO Auto-generated method stub
		return UserDao.findByUsername(userName);
	}

	@Override
	public int register(User user) {
		// TODO Auto-generated method stub
		return UserDao.register(user);
	}

	@Override
	public User userNameTest(String userName) {
		// TODO Auto-generated method stub
		return UserDao.userNameTest(userName);
	}

	@Override
	public User userMobileTest(String userMoblie) {
		// TODO Auto-generated method stub
		return UserDao.userMobileTest(userMoblie);
	}

	@Override
	public User userEmailTest(String userEmail) {
		// TODO Auto-generated method stub
		return UserDao.userEmailTest(userEmail);
	}

	@Override
	public User userNickNameTest(String userNickName) {
		// TODO Auto-generated method stub
		return UserDao.userNickNameTest(userNickName);
	}

	@Override
	public User GainNameId(String userName) {
		// TODO Auto-generated method stub
		return UserDao.GainNameId(userName);
	}

}
