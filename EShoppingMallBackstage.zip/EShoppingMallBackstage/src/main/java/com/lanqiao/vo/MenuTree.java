package com.lanqiao.vo;

import java.util.List;

public class MenuTree {

	private int cid;//菜单编号
	private String label;// 一级菜单名
	private List<MenuTree> children;// 二级菜单列表

	public int getCid() {
		return cid;
	}

	public void setCid(int cid) {
		this.cid = cid;
	}

	public String getLabel() {
		return label;
	}

	public void setLabel(String label) {
		this.label = label;
	}

	public List<MenuTree> getChildren() {
		return children;
	}

	public void setChildren(List<MenuTree> children) {
		this.children = children;
	}

}
