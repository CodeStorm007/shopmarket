package com.lanqiao.utils;

import java.nio.file.Paths;

import org.apache.lucene.analysis.Analyzer;
import org.apache.lucene.document.Document;
import org.apache.lucene.document.Field;
import org.apache.lucene.document.Field.Store;
import org.apache.lucene.document.TextField;
import org.apache.lucene.store.Directory;
import org.apache.lucene.store.FSDirectory;
import org.wltea.analyzer.lucene.IKAnalyzer;

import com.lanqiao.entity.ProductInfo;

public class LuceneUtil {

	private static Directory directory;
	private static Analyzer analyzer;

	static {
		try {
			directory = FSDirectory.open(Paths.get("E://CodeStormTeam//index"));
			analyzer = new IKAnalyzer();
		} catch (Exception e) {
			e.printStackTrace();

		}
	}

	public static Directory getDirectory() {
		return directory;
	}

	public static Analyzer getAnalyzer() {
		return analyzer;
	}

	public static Document objectToDocument(ProductInfo p) {
		Document document = new Document();

		Field productId = new TextField("productId", Integer.toString(p.getProductId()), Store.YES);
		Field productName = new TextField("productName", p.getProductName(), Store.YES);
		Field productDescription = new TextField("productDescription", p.getProductDescription(), Store.YES);
		Field productPrice = new TextField("productPrice", Double.toString(p.getProductPrice()), Store.YES);
		Field productStock = new TextField("productStock", Integer.toString(p.getProductStock()), Store.YES);
		Field categoryId = new TextField("categoryId", Integer.toString(p.getCategoryId()), Store.YES);
		Field categoryParentId = new TextField("categoryParentId", Integer.toString(p.getCategoryParentId()),
				Store.YES);
		Field productPicture = new TextField("productPicture", p.getProductPicture(), Store.YES);

		// 将field域设置到Document对象中
		document.add(productId);
		document.add(productName);
		document.add(productDescription);
		document.add(productPrice);
		document.add(productStock);
		document.add(categoryId);
		document.add(categoryParentId);
		document.add(productPicture);

		return document;
	}

	public static ProductInfo documentToObject(Document doc) {
		ProductInfo p = new ProductInfo();
		p.setProductId(Integer.parseInt(doc.get("productId")));
		p.setProductName(doc.get("productName"));
		p.setProductDescription(doc.get("productDescription"));
		p.setProductPrice(Double.parseDouble(doc.get("productPrice")));
		p.setProductStock(Integer.parseInt(doc.get("productStock")));
		p.setCategoryId(Integer.parseInt(doc.get("categoryId")));
		p.setCategoryParentId(Integer.parseInt(doc.get("categoryParentId")));
		p.setProductPicture(doc.get("productPicture"));
		return p;
	}

}
