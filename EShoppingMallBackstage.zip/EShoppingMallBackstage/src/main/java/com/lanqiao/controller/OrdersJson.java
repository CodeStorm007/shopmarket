package com.lanqiao.controller;

import java.sql.SQLException;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.lanqiao.entity.Orders;
import com.lanqiao.service.OrdersService;
import com.lanqiao.service.ProductInfoService;
import com.lanqiao.vo.OrderVoAdmin;
import com.lanqiao.vo.OrderVoUser;

@RestController
@CrossOrigin
@RequestMapping("/orders")
public class OrdersJson {

	@Autowired
	private OrdersService os;
	@Autowired
	private ProductInfoService ps;

	@RequestMapping("/queryAllOrders")
	public List<OrderVoAdmin> queryAllOrders() throws Exception {
		System.out.println(os.queryAllOrders());
		return os.queryAllOrders();
	}

	@RequestMapping("/queryOrdersById")
	public OrderVoAdmin queryOrdersById(Integer orderId) throws Exception {
		return os.queryOrdersById(orderId);
	}

	@RequestMapping("/queryOrdersByUserId")
	public List<OrderVoUser> queryOrdersByUserId(Integer userId) throws Exception {
		return os.queryOrdersByUserId(userId);
	}

	@RequestMapping("/addOrders")
	public int addOrders(Orders o) throws Exception {
		o.setOrderCost(o.getOrderQuantity() * ps.queryPriceByProductId(o.getProductId()));
		return os.addOrders(o);
	}

	@RequestMapping("/deleteOrders")
	public int deleteOrders(Integer userId, Integer orderId) throws Exception {
		return os.deleteOrders(userId, orderId);
	}

	@RequestMapping("/updateOrders")
	public int updateOrders(Integer orderStatus, Integer orderId) throws Exception {
		return os.updateOrders(orderStatus, orderId);
	}

	@RequestMapping("/queryProductMsgByPD")
	public List<OrderVoUser> queryProductMsgByPD(String productDescription) throws SQLException {
		return os.queryProductMsgByPD(productDescription);
	}
}
