package com.lanqiao.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.lanqiao.entity.User;
import com.lanqiao.service.UserService;
import com.lanqiao.utils.R;

@RestController
@CrossOrigin
@RequestMapping("/reg")
public class RegisterController {
	@Autowired
	private UserService userservice;

	@RequestMapping("/register")
	public R<User> register(User user) {
		R<User> r = new R<User>();
		User u1 = userservice.userNameTest(user.getUserName());
		if (u1 != null) {
			r.setCode(0);
			r.setMsg("用户名已存在！");
			return r;
		}
		User u2 = userservice.userMobileTest(user.getUserMobile());
		if (u2 != null) {
			r.setCode(0);
			r.setMsg("手机号已存在！");
			return r;
		}
		User u3 = userservice.userEmailTest(user.getUserEmail());
		if (u3 != null) {
			r.setCode(0);
			r.setMsg("邮箱地址已存在！");
			return r;
		}
		User u4 = userservice.userNickNameTest(user.getUserNickName());
		System.out.print(u4);
		if (u4 != null) {
			r.setCode(0);
			r.setMsg("昵称已存在！");
			return r;
		}

		userservice.register(user);
		r.setCode(1);
		r.setMsg("注册成功");
		return r;
	}

}
