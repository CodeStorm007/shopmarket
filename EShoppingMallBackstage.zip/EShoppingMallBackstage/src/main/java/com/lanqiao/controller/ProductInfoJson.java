package com.lanqiao.controller;

import java.io.File;
import java.util.List;
import java.util.UUID;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.lanqiao.entity.ProductInfo;
import com.lanqiao.service.ProductInfoIndexService;
import com.lanqiao.service.ProductInfoService;

@RestController
@CrossOrigin
@RequestMapping("/productInfo")
public class ProductInfoJson {

	@Autowired
	private ProductInfoService ps;
	@Autowired
	private ProductInfoIndexService pis;

	@RequestMapping("/queryAllProduct")
	public List<ProductInfo> queryAllProduct() throws Exception {
		return ps.queryAllProduct();
	}

	@RequestMapping("/queryProductById")
	public ProductInfo queryProductById(int productId) throws Exception {
		return ps.queryProductById(productId);
	}

	@RequestMapping("/queryProductByType")
	public List<ProductInfo> queryProductByType(int category_id) throws Exception {
		return ps.queryProductByType(category_id);
	}

	@RequestMapping("/queryProductByParentType")
	public List<ProductInfo> queryProductByParentType(int category_parent_id) throws Exception {
		return ps.queryProductByParentType(category_parent_id);
	}

	@RequestMapping("/addProduct")
	public int addProduct(ProductInfo p, MultipartFile Picture) throws Exception {
		String fileType = Picture.getOriginalFilename()
				.substring(Picture.getOriginalFilename().lastIndexOf("."));
		String filename = String.valueOf(UUID.randomUUID()).replace("-", "") + fileType; // sfjkjgksfsjf

		File file = new File("E:\\CodeStormTeam\\ShoppingMarket\\img\\" + filename);
		Picture.transferTo(file);
		p.setProductPicture(filename);
		int result = ps.addProduct(p);
		pis.addProduct(p);
		return result;
	}

	@RequestMapping("/deleteProduct")
	public int deleteProduct(Integer productId) throws Exception {
		int result = ps.deleteProduct(productId);
		pis.deleteProduct(productId);
		return result;
	}

	@RequestMapping("/updateProduct")
	public int updateProduct(ProductInfo p) throws Exception {
		int result = ps.updateProduct(p);
		pis.updateProduct(p);
		return result;
	}

	@RequestMapping("/queryProductStock")
	public int queryProductStock(Integer product_id) throws Exception {
		return ps.queryProductStock(product_id);
	}

	@RequestMapping("/reduceProductStock")
	public int reduceProductStock(Integer product_id, Integer order_quantity) throws Exception {
		return ps.reduceProductStock(product_id, order_quantity);
	}

	@RequestMapping("/addProductStock")
	public int addProductStock(Integer product_id, Integer order_quantity) throws Exception {
		return ps.addProductStock(product_id, order_quantity);
	}

	@RequestMapping("/search")
	public List<ProductInfo> Search(String key) throws Exception {
		return pis.queryAllProduct(key);
	}
}
