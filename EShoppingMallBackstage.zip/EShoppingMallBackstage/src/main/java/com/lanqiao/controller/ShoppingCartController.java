package com.lanqiao.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.github.pagehelper.PageInfo;
import com.lanqiao.entity.ShoppingCart;
import com.lanqiao.service.ShoppingCartService;
import com.lanqiao.utils.R;
import com.lanqiao.vo.ShoppingProductVO;

@RestController
@CrossOrigin
public class ShoppingCartController {
	@Autowired
	private ShoppingCartService service;

	// @RequestMapping("/getAll")
	// public List<ShoppingCart> getAll() {
	// //查询所有库中所有加入购物车中的商品信息
	// List<ShoppingCart> list=service.getAll();
	// return list;
	// }

	@GetMapping("getAll")
	public R<List<ShoppingCart>> getAll() {
		R<List<ShoppingCart>> r = new R<>();
		r.setCode(1);
		List<ShoppingCart> s = service.getAll();
		if (s != null) {
			r.setData(s);
			r.setMsg("查询全部成功");
			return r;
		} else {
			r.setMsg("购物车无商品，此电商无用！！！");
			return r;
		}

	}

	//
	// @RequestMapping("/getByUserId")
	// public List<ShoppingProductVO> getByUserId(int userid){
	// //根据每个人的id查所属商品信息
	// List<ShoppingProductVO> list=service.getByUserId(userid);
	// return list;
	// }
	@GetMapping("getByUserIdQueryCart")
	// 根据每个人的id查所属商品信息
	public R<List<ShoppingProductVO>> getByUserIdQueryCart(int userId) {
		R<List<ShoppingProductVO>> r = new R<>();
		r.setCode(1);
		List<ShoppingProductVO> s = service.getByUserId(userId);
		if (s != null) {
			r.setData(s);
			r.setMsg("查询此人所拥有所有商品成功");
			return r;
		} else {
			r.setMsg("此人无商品");
			return r;
		}
	}
	// @RequestMapping("/insertCart")
	// public int insertCart(ShoppingCart shoppingCart) {
	//
	// ShoppingCart shop=new ShoppingCart();
	// //从前端接收信息
	// shop.setOrderQuantity(555);
	// shop.setProductId(3);
	// shop.setProductPrice(169);
	// shop.setUserId(1);
	//
	// int cart=service.insertCart(shop);
	// return cart;
	// }

	@GetMapping("insertCart")
	public R<ShoppingCart> insertCart(ShoppingCart shop) {
		R<ShoppingCart> r = new R<>();
		r.setCode(1);
		// ShoppingCart shop = new ShoppingCart();
		// // 从前端接收信息
		// shop.setOrderQuantity(10000);
		// shop.setProductId(4);
		// shop.setProductPrice(200);
		// shop.setUserId(1);

		List<ShoppingProductVO> list = service.getByUserId(shop.getUserId());
		for (int i = 0; i < list.size(); i++) {
			if (shop.getProductId() == list.get(i).getProtId()) {
				int orderQuantity = list.get(i).getProNum() + shop.getOrderQuantity();
				int s = service.update(orderQuantity, shop.getProductId(), shop.getUserId());
				if (s == 0) {
					r.setMsg("商品已有，添加数量失败！");
					return r;
				} else {
					r.setMsg("商品已有，添加数量" + shop.getOrderQuantity());
					return r;
				}
			}
		}
		shop.setSum(shop.getOrderQuantity() * shop.getProductPrice());
		int a = service.insertCart(shop);
		if (a == 0) {
			r.setMsg("添加失败！");
			return r;
		} else {
			r.setMsg("添加成功");
			return r;
		}

	}

	// @RequestMapping("/update")
	// public int update(int orderQuantity,int productId,int userid) {
	// int quantity=service.update(orderQuantity, productId, userid);
	// return quantity;
	// }

	@GetMapping("update")
	public R<Integer> update(int orderQuantity, int productId, int userid) {
		R<Integer> r = new R<>();
		int s = service.update(orderQuantity, productId, userid);
		if (s == 0) {
			r.setMsg("更改商品数量失败，请重试！");
			return r;
		} else {
			r.setMsg("更改商品数量成功");
			return r;
		}
	}

	@RequestMapping("delete")
	public R<Integer> delete(int userid, int productId) {
		R<Integer> r = new R<>();
		int s = service.delete(userid, productId);
		if (s == 0) {
			r.setMsg("删除失败");
			return r;
		} else {
			r.setMsg("删除成功");
			return r;
		}
	}

	// 分页Test
	@GetMapping("/Page") // 方法[getPage]是在.class文件中发现的，但不能在class对象中解析
	public R<PageInfo<ShoppingCart>> Page() {
		PageInfo<ShoppingCart> pageInfo = service.getpage(1, 2);
		R<PageInfo<ShoppingCart>> r = new R<>();
		r.setCode(1);
		if (pageInfo.getList() != null && pageInfo.getList().size() > 0) {
			r.setMsg("success");
			r.setData(pageInfo);
		} else {
			r.setMsg("没有数据！");
		}
		return r;
	}

}
