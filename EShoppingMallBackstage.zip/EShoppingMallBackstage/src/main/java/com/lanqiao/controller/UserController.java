package com.lanqiao.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.lanqiao.entity.User;
import com.lanqiao.service.UserService;
import com.lanqiao.utils.R;

@RestController
@CrossOrigin
public class UserController {
	@Autowired
	private UserService userService;

	@RequestMapping("/login")
	public R<User> login(String userName, String passWord) {
		R<User> r = new R<User>();
		r.setCode(1);
		User u = userService.findByUsername(userName);
		if (u != null) {
			u = userService.login(userName, passWord);
			if (u != null) {
				r.setMsg("登录成功");
				r.setData(u);
			} else {
				r.setMsg("密码错误");
			}
		} else {
			r.setMsg("用户名不存在");
		}
		return r;
	}

	@RequestMapping("/gain")
	public User GainNameId(String userName) {
		User m = userService.GainNameId(userName);
		return m;
	}

}
