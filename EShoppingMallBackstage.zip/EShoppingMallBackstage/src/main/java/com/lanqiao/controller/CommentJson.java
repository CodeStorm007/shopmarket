package com.lanqiao.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.lanqiao.entity.Comment;
import com.lanqiao.service.CommentService;
import com.lanqiao.vo.CommentVoProduct;

@RestController
@CrossOrigin
@RequestMapping("/comment")
public class CommentJson {
	@Autowired
	private CommentService service;

	@RequestMapping("/showAllCommentByProId")
	public List<CommentVoProduct> showAllCommentByProId(int productId) {
		return service.showAllCommentByProId(productId);
	}

	@RequestMapping("/addComment")
	public int addComment(Comment o) throws Exception {
		return service.addComment(o);
	}
}
