package com.lanqiao.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.lanqiao.entity.Category;
import com.lanqiao.service.CategoryService;
import com.lanqiao.vo.MenuTree;

@RestController
@CrossOrigin
@RequestMapping("/category")
public class CategoryJson {

	@Autowired
	private CategoryService cs;

	@RequestMapping("/queryAllCategory")
	public List<Category> queryAllCategory() throws Exception {
		return cs.queryAllCategory();
	}

	@RequestMapping("/queryCategoryById")
	public List<Category> queryCategoryById(int categoryId) throws Exception {
		return cs.queryCategoryById(categoryId);
	}

	@RequestMapping("/queryCategoryByParentId")
	public List<Category> queryCategoryByParentId(int categoryParentId) throws Exception {
		return cs.queryCategoryByParentId(categoryParentId);
	}

	@RequestMapping("/addCategory")
	public int addCategory(Category c) throws Exception {
		return cs.addCategory(c);
	}

	@RequestMapping("/deleteCategory")
	public int deleteCategory(Integer categoryId) throws Exception {
		return cs.deleteCategory(categoryId);
	}

	@RequestMapping("/updateCategory")
	public int updateCategory(Category c) throws Exception {
		return cs.updateCategory(c);
	}
	
	@RequestMapping("/menu")
	public List<MenuTree> getTree() throws Exception{
		return cs.getMenuTree() ;
	}
}
