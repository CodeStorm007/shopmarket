package com.lanqiao.controller;

import org.apache.ibatis.annotations.Param;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.lanqiao.entity.Admin;
import com.lanqiao.service.AdminService;
import com.lanqiao.utils.R;

@CrossOrigin
@RestController
@RequestMapping("/test")
public class AdminController {
	@Autowired
	private AdminService AdminService;

	@RequestMapping("/login")
	public R<Admin> login(@Param("adminName") String adminName, @Param("adminPassword") String adminPassword)
			throws Exception {

		R<Admin> r = new R<Admin>();
		r.setCode(1);
		Admin a = AdminService.queryAdminByName(adminName);
		if (a != null) {
			a = AdminService.query(adminName, adminPassword);
			if (a != null) {
				r.setMsg("登录成功");
				r.setData(a);
			} else {
				r.setMsg("密码错误");
			}
		} else {
			r.setMsg("用户名不存在！");
		}

		return r;
	}

	@RequestMapping("/register")
	//
	public R<Admin> register(Admin a) throws Exception {
		R<Admin> r = new R<Admin>();
		r.setCode(1);
		Admin an = AdminService.queryAdminByName(a.getAdminName());
		if (an != null) {
			r.setMsg("该用户名已存在");
		} else {
			Admin am = AdminService.queryAdminByMobile(a.getAdminMobile());
			if (am != null) {
				r.setMsg("请更换电话号码");
			} else {
				r.setMsg("注册成功");
				r.setData(a);
				AdminService.addAdmin(a);
			}
		}
		return r;

	}

	@RequestMapping("/delete")
	public R<Admin> delete(Integer a) throws Exception {
		R<Admin> r = new R<Admin>();
		int result = AdminService.deleteAdmin(a);
		if (result > 0) {
			r.setMsg("删除成功");
		} else {
			r.setMsg("删除失败");
		}
		return r;
	}

	@RequestMapping("/update")
	public R update(Admin Adminid) throws Exception {
		R r = new R();
		int result = AdminService.updateAdmin(Adminid);
		if (result > 0) {
			r.setMsg("删除成功");
		} else {
			r.setMsg("删除失败");
		}
		return r;
	}

}
