package com.lanqiao.dao;

import java.util.List;

import com.lanqiao.entity.Comment;
import com.lanqiao.vo.CommentVoProduct;

public interface CommentDao {
	// 根据商品编号查所用用户的评论信息
	public List<CommentVoProduct> showAllCommentByProId(int productId);
	//用户下单之后添加评论，可追加评论
	public int addComment(Comment o) throws Exception;
}
