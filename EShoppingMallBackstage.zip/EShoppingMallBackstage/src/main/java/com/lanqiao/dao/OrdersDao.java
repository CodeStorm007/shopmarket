package com.lanqiao.dao;

import java.sql.SQLException;
import java.util.List;

import org.apache.ibatis.annotations.Param;

import com.lanqiao.entity.Orders;
import com.lanqiao.vo.OrderVoAdmin;
import com.lanqiao.vo.OrderVoUser;

public interface OrdersDao {

	// 查询所有订单-管理员
	public List<OrderVoAdmin> queryAllOrders() throws Exception;

	// 根据订单编号查询订单-管理员
	public OrderVoAdmin queryOrdersById(Integer orderId) throws Exception;

	// 根据用户编号查询订单-用户
	public List<OrderVoUser> queryOrdersByUserId(Integer userId) throws Exception;

	// 添加订单-用户
	public int addOrders(Orders o) throws Exception;

	// 删除订单-用户取消
	public int deleteOrders(@Param("user_id") Integer userId, @Param("order_id") Integer orderId) throws Exception;

	// 更新订单-管理员
	public int updateOrders(@Param("order_status") Integer orderStatus, @Param("order_id") Integer orderId)
			throws Exception;

	// 根据订单编号查询购买的商品数量
	public int queryOrderQuantity(Integer orderId) throws Exception;

	// 根据订单编号查询购买的商品的商品编号
	public int queryProductId(Integer orderId) throws Exception;

	// 根据商品描述关键字模糊查询订单
	public List<OrderVoUser> queryProductMsgByPD(@Param("productDescription")String productDescription) throws SQLException;

}
