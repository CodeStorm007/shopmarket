package com.lanqiao.dao;

import java.util.List;

import org.apache.ibatis.annotations.Param;

import com.lanqiao.entity.ShoppingCart;
import com.lanqiao.vo.ShoppingProductVO;

public interface ShoppingCartDao {
	//查询购物车表
	List<ShoppingCart> getAll();
	//根据用户查询用户商品信息、数量、单价、商品名字
	List<ShoppingProductVO> getByUserId(int userId);
	
	//商品加入购物车
	int insertCart(ShoppingCart shopcaCart);
	//根据每人的商品编号更新商品数量
	/**
	 * 
	 * @param orderQuantity
	 * @param productId
	 * @param userid
	 * @return
	 */
	int update(@Param("orderQuantity") int orderQuantity,@Param("productId") int productId,@Param("userId")int userId);
	/**
	 * 
	 * @param shoppingId
	 * @param userid
	 * @return
	 */
	int delete(@Param("userId")int userId,@Param("productId")int productId);
	
	
	
	
	
	
}
