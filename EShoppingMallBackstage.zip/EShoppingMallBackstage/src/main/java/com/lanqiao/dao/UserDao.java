package com.lanqiao.dao;

import org.apache.ibatis.annotations.Param;

import com.lanqiao.entity.User;

public interface UserDao {

	public User login(@Param("userName") String userName, @Param("passWord") String passWord);

	User findByUsername(@Param("userName") String userName);
	
	//获取用户id跟昵称
	public User GainNameId(String userName);
	
	public User userNameTest(String userName);
	public User userMobileTest(String userMoblie);
	public User userEmailTest(String userEmail);
	public User userNickNameTest(String userNickName);
	public int register(User user);//注册，添加
}
