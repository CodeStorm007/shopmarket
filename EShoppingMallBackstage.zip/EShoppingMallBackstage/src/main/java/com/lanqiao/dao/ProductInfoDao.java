package com.lanqiao.dao;

import java.util.List;

import org.apache.ibatis.annotations.Param;

import com.lanqiao.entity.ProductInfo;

public interface ProductInfoDao {

	// 查询所有商品
	public List<ProductInfo> queryAllProduct();

	// 根据商品编号查询商品
	public ProductInfo queryProductById(int product_id) throws Exception;

	// 根据所属分类ID查询商品
	public List<ProductInfo> queryProductByType(int category_id) throws Exception;

	// 根据所属二级分类ID查询商品
	public List<ProductInfo> queryProductByParentType(int category_parent_id) throws Exception;

	// 添加商品
	public int addProduct(ProductInfo p) throws Exception;

	// 删除商品
	public int deleteProduct(Integer productId) throws Exception;

	// 更新商品
	public int updateProduct(ProductInfo p) throws Exception;

	// 查询所有的商品分类编号
	public List queryAllCategoryId() throws Exception;

	// 根据商品编号查询商品库存
	public int queryProductStock(Integer product_id) throws Exception;

	// 根据商品编号和商品数量更新商品库存
	// 当用户下单时,减少商品库存
	public int reduceProductStock(@Param("productId") Integer productId, @Param("orderQuantity") Integer orderQuantity)
			throws Exception;

	// 当用户取消单时,增加商品库存
	public int addProductStock(@Param("productId") Integer productId, @Param("orderQuantity") Integer orderQuantity)
			throws Exception;

	// 根据商品编号查询商品价格
	public double queryPriceByProductId(int productId) throws Exception;
}
